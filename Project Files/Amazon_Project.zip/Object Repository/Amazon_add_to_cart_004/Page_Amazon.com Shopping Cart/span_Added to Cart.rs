<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Added to Cart</name>
   <tag></tag>
   <elementGuidId>65fc15d5-6dfd-4819-a1c9-bec3064ce683</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-size-medium-plus.a-color-base.sw-atc-text.a-text-bold</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>44c9c1ef-fac0-4e68-ab0d-43220498016f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-medium-plus a-color-base sw-atc-text a-text-bold</value>
      <webElementGuid>de31ee37-fee3-493f-9f5f-1a4b09df1097</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            Added to Cart
        
    </value>
      <webElementGuid>057758d9-3c3f-4ab0-b319-07e0956006f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;NATC_SMART_WAGON_CONF_MSG_SUCCESS&quot;)/span[@class=&quot;a-size-medium-plus a-color-base sw-atc-text a-text-bold&quot;]</value>
      <webElementGuid>c50039b5-9f3c-43a1-8139-adda723872d5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/span</value>
      <webElementGuid>7f5273ea-cbcc-42ad-bad6-9a54e2c4e0b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/span</value>
      <webElementGuid>ca0a1b4e-f189-4318-899b-1e48e880c65f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        
            Added to Cart
        
    ' or . = '
        
            Added to Cart
        
    ')]</value>
      <webElementGuid>d5601512-d2f2-4497-9a97-a1a4fe1b39fc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
